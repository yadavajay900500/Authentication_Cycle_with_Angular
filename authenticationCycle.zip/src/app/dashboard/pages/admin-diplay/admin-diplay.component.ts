import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-diplay',
  templateUrl: './admin-diplay.component.html',
  styleUrls: ['./admin-diplay.component.scss']
})
export class AdminDiplayComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
