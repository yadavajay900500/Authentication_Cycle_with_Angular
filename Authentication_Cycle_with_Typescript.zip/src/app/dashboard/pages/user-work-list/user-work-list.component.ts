import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-work-list',
  templateUrl: './user-work-list.component.html',
  styleUrls: ['./user-work-list.component.scss']
})
export class UserWorkListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
